"""
Compatible with Kodi 19.x "Matrix" and above
"""
from __future__ import absolute_import, division, unicode_literals
import re
import math
import json
import os
import time
from urllib.parse import parse_qsl
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
from .globals import G
from .stalker_cache import StalkerCache
from .utils import ask_for_input, get_int_value
from .api import Api
from .loggers import Logger
from .tmdb import TmdbClient, TmdbRateLimitError, _CACHE_MISS


_tmdb_client_singleton = None
_rate_limit_notified = False  # show the rate-limit toast only once per plugin run
_lang_tag_prefix_re = None
_lang_tag_suffix_re = None


def _build_lang_tag_pattern():
    """Build and cache the regex patterns for language tag removal."""
    global _lang_tag_prefix_re, _lang_tag_suffix_re
    cfg = G.display_config
    if not cfg.remove_lang_tags or not cfg.lang_tag_keywords:
        _lang_tag_prefix_re = None
        _lang_tag_suffix_re = None
        return
    escaped = [re.escape(kw) for kw in cfg.lang_tag_keywords]
    group = '|'.join(escaped)
    # Prefix: "de - Action" → "Action"
    _lang_tag_prefix_re = re.compile(r'^(?:' + group + r')\s*[-–]\s*', re.IGNORECASE)
    # Suffix: "(DE)" or "[DE]" or "- DE"
    _lang_tag_suffix_re = re.compile(
        r'\s*(?:'
        r'[\(\[]\s*(?:' + group + r')\s*[\)\]]'
        r'|[-–]\s*(?:' + group + r')'
        r')\s*$',
        re.IGNORECASE
    )


def _clean_lang_tags(name):
    """Remove language prefix/suffix tags from a name if enabled."""
    if _lang_tag_prefix_re is None or not name:
        return name
    cleaned = _lang_tag_prefix_re.sub('', name)
    cleaned = _lang_tag_suffix_re.sub('', cleaned)
    return cleaned.strip() if cleaned.strip() else name


def _show_rate_limit_notification():
    """Show a small Kodi toast notification about the TMDB rate limit (once per run)."""
    global _rate_limit_notified
    if not _rate_limit_notified:
        _rate_limit_notified = True
        xbmc.executebuiltin(
            'Notification(Stalker VOD,'
            'TMDB-Limit erreicht – Metadaten für diese Seite pausiert.,'
            '6000,'
            'DefaultIconWarning.png)'
        )


def _get_tmdb_client():
    """Return a TmdbClient singleton if TMDB is enabled and an API key is set, else None.

    Reuses the same instance within one plugin run so the disk cache is only
    loaded once per page render instead of once per list item.
    """
    global _tmdb_client_singleton
    cfg = G.tmdb_config
    if not cfg.enabled or not cfg.api_key:
        return None
    if _tmdb_client_singleton is None:
        _tmdb_client_singleton = TmdbClient(cfg.api_key, cfg.language, cfg.cache_days)
    return _tmdb_client_singleton


def _apply_tmdb_movie(list_item, video_info, title, year, stalker_poster):
    """Enrich a movie ListItem with TMDB data. Always calls setArt."""
    tmdb = _get_tmdb_client()
    if tmdb is not None:
        try:
            info = tmdb.get_movie_info(title, year if year else None)
        except TmdbRateLimitError:
            _show_rate_limit_notification()
            list_item.setArt({'poster': stalker_poster})
            return
        if info:
            _apply_tmdb_to_item(list_item, video_info, info, stalker_poster)
            return
    list_item.setArt({'poster': stalker_poster})


def _apply_tmdb_tv(list_item, video_info, title, year, stalker_poster):
    """Enrich a TV/Series ListItem with TMDB data. Always calls setArt."""
    tmdb = _get_tmdb_client()
    if tmdb is not None:
        try:
            info = tmdb.get_tv_info(title, year if year else None)
        except TmdbRateLimitError:
            _show_rate_limit_notification()
            list_item.setArt({'poster': stalker_poster})
            return
        if info:
            _apply_tmdb_to_item(list_item, video_info, info, stalker_poster)
            return
    list_item.setArt({'poster': stalker_poster})


def _apply_tmdb_to_item(list_item, video_info, info, stalker_poster):
    """Write TMDB fields onto a ListItem/InfoTagVideo.

    Each field is only applied if the corresponding setting is enabled.
    tmdb_id and year are always applied (no bandwidth cost, pure metadata).
    """
    cfg = G.tmdb_config
    if info.get('tmdb_id'):
        video_info.setUniqueID('tmdb', info['tmdb_id'], True)
        list_item.setProperty('tmdb_id', info['tmdb_id'])
    if cfg.use_plot and info.get('plot'):
        video_info.setPlot(info['plot'])
        video_info.setPlotOutline(info['plot'])
    if cfg.use_rating and info.get('rating'):
        try:
            video_info.setRating('tmdb', float(info['rating']), info.get('votes', 0), True)
        except TypeError:
            pass
    if info.get('year') and info['year'] > 0:
        video_info.setYear(info['year'])
    if cfg.use_genres and info.get('genres'):
        video_info.setGenres(info['genres'])
    poster = (info.get('poster') if cfg.use_poster else None) or stalker_poster
    fanart = info.get('fanart') if cfg.use_fanart else None
    art = {'poster': poster}
    if fanart:
        art['fanart'] = fanart
        art['landscape'] = fanart
    list_item.setArt(art)


def _load_filter_ids(filter_file):
    """Load saved category IDs from a filter JSON file. Returns (found, set_of_ids)."""
    try:
        f = xbmcvfs.File(filter_file, 'r')
        content = f.read()
        f.close()
        if content:
            return True, set(json.loads(content))
    except Exception:
        pass
    return False, set()


def _save_filter_ids(filter_file, id_list):
    """Persist a list of category ID strings to a filter JSON file."""
    try:
        f = xbmcvfs.File(filter_file, 'w')
        f.write(json.dumps(id_list))
        f.close()
    except Exception as exc:
        Logger.debug('Folder filter: error saving {}: {}'.format(filter_file, exc))


def _apply_category_filter(categories, filter_file):
    """Return a filtered copy of categories based on current filter settings.

    Manuelle Auswahl hat Vorrang vor Stichwörtern.
    Sind beide Schalter aus → alle Kategorien anzeigen.
    """
    cfg = G.filter_config
    if not categories:
        return categories

    # Manuelle Auswahl hat Vorrang
    if cfg.use_manual:
        file_exists, stored_ids = _load_filter_ids(filter_file)
        if not file_exists:
            return categories  # noch nicht konfiguriert → alles anzeigen
        return [c for c in categories if str(c['id']) in stored_ids]

    # Stichwörter-Filter
    if cfg.use_keywords:
        if not cfg.keywords:
            return categories
        result = []
        for cat in categories:
            title_lower = cat['title'].lower()
            if any(re.search(r'\b' + re.escape(kw) + r'\b', title_lower) for kw in cfg.keywords):
                result.append(cat)
        return result

    # Beide Schalter aus → alles anzeigen
    return categories


class StalkerAddon:
    """Stalker Addon"""
    @staticmethod
    def __toggle_favorites(video_id, add, _type):
        """Remove/add favorites and refresh"""
        Logger.debug('Toggle Favorites video_id={}, add={}, _type={}'.format(video_id, add, _type))
        if add:
            Api.add_favorites(video_id, _type)
        else:
            Api.remove_favorites(video_id, _type)
        xbmc.executebuiltin('Container.Refresh')

    @staticmethod
    def __play_video(params):
        """Play video"""
        Logger.debug('Play video {}'.format(params))
        stream_url = Api.get_vod_stream_url(params['video_id'], params['series'], params.get('cmd', ''), params.get('use_cmd', '0'))
        play_item = xbmcgui.ListItem(path=stream_url)
        video_info = play_item.getVideoInfoTag()
        title = params.get('title', '')
        video_info.setTitle(title)
        video_info.setOriginalTitle(title)
        video_info.setMediaType('movie')
        episode_no = get_int_value(params, 'series')
        if episode_no > 0:
            video_info.setEpisode(episode_no)
            video_info.setSeason(get_int_value(params, 'season_no'))
            video_info.setMediaType('episode')
            video_info.setTvShowTitle(title)
        xbmcplugin.setResolvedUrl(G.get_handle(), True, listitem=play_item)

    @staticmethod
    def __play_tv(params):
        """Play TV Channel"""
        Logger.debug('Play TV {}'.format(params))
        stream_url = Api.get_tv_stream_url(params)
        play_item = xbmcgui.ListItem(path=stream_url)
        xbmcplugin.setResolvedUrl(G.get_handle(), True, listitem=play_item)

    @staticmethod
    def __list_tv_genres():
        """List the TV channel genres"""
        Logger.debug('List TV Genres')
        xbmcplugin.setPluginCategory(G.get_handle(), 'TV CHANNELS')
        xbmcplugin.setContent(G.get_handle(), 'videos')
        list_item = xbmcgui.ListItem(label='TV FAVORITES')
        url = G.get_plugin_url({'action': 'tv_favorites', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Add a search option
        list_item = xbmcgui.ListItem(label='TV SEARCH')
        list_item.setArt({'thumb': G.get_custom_thumb_path('search.png')})
        url = G.get_plugin_url({'action': 'tv_search', 'fav': 0, 'isContextMenuSearch': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        genres = _apply_category_filter(Api.get_tv_genres(), G.get_filter_file_path('tv'))
        for genre in genres:
            genre_name = _clean_lang_tags(genre['title'])
            list_item = xbmcgui.ListItem(label=genre_name.upper())
            fav_url = G.get_plugin_url({'action': 'tv_listing', 'category': genre_name, 'category_id': genre['id'], 'page': 1,
                                        'update_listing': False, 'search_term': '', 'fav': 1})
            search_url = G.get_plugin_url({'action': 'tv_search', 'category': genre_name, 'category_id': genre['id'], 'fav': 0})
            list_item.addContextMenuItems(
                [('Favorites', f'Container.Update({fav_url})'), ('Search', f'RunPlugin({search_url}, False)')])
            url = G.get_plugin_url({'action': 'tv_listing', 'category': genre_name.upper(), 'category_id': genre['id'], 'page': 1,
                                    'update_listing': False})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __list_vod_categories():
        """List vod categories"""
        Logger.debug('List VOD Categories')
        xbmcplugin.setPluginCategory(G.get_handle(), 'VOD')
        xbmcplugin.setContent(G.get_handle(), 'videos')

        list_item = xbmcgui.ListItem(label='VOD FAVORITES')
        url = G.get_plugin_url({'action': 'vod_favorites', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Add a search option
        list_item = xbmcgui.ListItem(label='VOD SEARCH')
        list_item.setArt({'thumb': G.get_custom_thumb_path('search.png')})
        url = G.get_plugin_url({'action': 'vod_search', 'fav': 0, 'isContextMenuSearch': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Add a filter option (only visible when TMDB is enabled)
        if G.tmdb_config.enabled and G.tmdb_config.api_key:
            list_item = xbmcgui.ListItem(label='VOD FILTER')
            list_item.setArt({'thumb': G.get_custom_thumb_path('filter.png')})
            url = G.get_plugin_url({'action': 'vod_filter'})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        stalker_cache = StalkerCache(G.addon_config.token_path, cache_days=G.addon_config.stalker_cache_days)
        raw_cats = stalker_cache.get_categories('vod')
        if raw_cats is None:
            raw_cats = Api.get_vod_categories() or []
            stalker_cache.set_categories('vod', raw_cats)
        categories = _apply_category_filter(raw_cats, G.get_filter_file_path('vod'))
        for category in categories:
            cat_name = _clean_lang_tags(category['title'])
            list_item = xbmcgui.ListItem(label=cat_name)
            fav_url = G.get_plugin_url({'action': 'vod_listing', 'category': cat_name, 'category_id': category['id'], 'page': 1,
                                        'update_listing': False, 'search_term': '', 'fav': 1})
            search_url = G.get_plugin_url({'action': 'vod_search', 'category': cat_name, 'category_id': category['id'], 'fav': 0})
            list_item.addContextMenuItems([('Favorites', f'Container.Update({fav_url})'), ('Search', f'RunPlugin({search_url}, False)')])
            url = G.get_plugin_url({'action': 'vod_listing', 'category': cat_name, 'category_id': category['id'], 'page': 1,
                                    'update_listing': False, 'search_term': '', 'fav': 0})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __list_series_categories():
        """List series categories"""
        Logger.debug('List Series Categories')
        xbmcplugin.setPluginCategory(G.get_handle(), 'SERIES')
        xbmcplugin.setContent(G.get_handle(), 'videos')

        list_item = xbmcgui.ListItem(label='SERIES FAVORITES')
        url = G.get_plugin_url({'action': 'series_favorites', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Add a search option
        list_item = xbmcgui.ListItem(label='SERIES SEARCH')
        list_item.setArt({'thumb': G.get_custom_thumb_path('search.png')})
        url = G.get_plugin_url({'action': 'series_search', 'fav': 0, 'isContextMenuSearch': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        # Add a filter option (only visible when TMDB is enabled)
        if G.tmdb_config.enabled and G.tmdb_config.api_key:
            list_item = xbmcgui.ListItem(label='SERIES FILTER')
            list_item.setArt({'thumb': G.get_custom_thumb_path('filter.png')})
            url = G.get_plugin_url({'action': 'series_filter'})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        stalker_cache = StalkerCache(G.addon_config.token_path, cache_days=G.addon_config.stalker_cache_days)
        raw_cats = stalker_cache.get_categories('series')
        if raw_cats is None:
            raw = Api.get_series_categories()
            raw_cats = raw if isinstance(raw, list) else []
            stalker_cache.set_categories('series', raw_cats)
        categories = _apply_category_filter(raw_cats, G.get_filter_file_path('series'))
        for category in categories:
            cat_name = _clean_lang_tags(category['title'])
            list_item = xbmcgui.ListItem(label=cat_name)
            fav_url = G.get_plugin_url({'action': 'series_listing', 'category': cat_name, 'category_id': category['id'], 'page': 1,
                                        'update_listing': False, 'search_term': '', 'fav': 1})
            search_url = G.get_plugin_url({'action': 'series_search', 'category': cat_name, 'category_id': category['id'], 'fav': 0})
            list_item.addContextMenuItems([('Favorites', f'Container.Update({fav_url})'), ('Search', f'RunPlugin({search_url}, False)')])
            url = G.get_plugin_url({'action': 'series_listing', 'category': cat_name, 'category_id': category['id'], 'page': 1,
                                    'update_listing': False, 'search_term': '', 'fav': 0})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __list_channels(params):
        """List the TV Channels"""
        Logger.debug('List Channels {}'.format(params))
        search_term = params.get('search_term', '')
        page = params['page']
        plugin_category = 'TV - ' + params['category'] if params.get('fav', '0') != '1' else 'TV - ' + params['category'] + ' - FAVORITES'
        xbmcplugin.setPluginCategory(G.get_handle(), plugin_category)
        xbmcplugin.setContent(G.get_handle(), 'videos')
        videos = Api.get_tv_channels(params['category_id'], page, search_term, params.get('fav', 0))
        StalkerAddon.__create_tv_listing(videos, params)

    @staticmethod
    def __create_tv_listing(videos, params):
        update_listing = params['update_listing']
        item_count = len(videos['data'])
        directory_items = []
        for video in videos['data']:
            label = _clean_lang_tags(video['name'])
            if video.get('fav', 0) == 1:
                label = label + ' ★'
            list_item = xbmcgui.ListItem(label, label)
            video_info = list_item.getVideoInfoTag()
            video_info.setPlaycount(0)
            list_item.setProperty('IsPlayable', 'true')
            if video.get('fav', 0) == 1:
                url = G.get_plugin_url({'action': 'remove_fav', 'video_id': video['id'], '_type': 'itv'})
                list_item.addContextMenuItems([('Remove from favorites', f'RunPlugin({url}, False)')])
            else:
                url = G.get_plugin_url({'action': 'add_fav', 'video_id': video['id'], '_type': 'itv'})
                list_item.addContextMenuItems([('Add to favorites', f'RunPlugin({url}, False)')])
            if 'logo' in video:
                list_item.setArt({'icon': video['logo'], 'thumb': video['logo'], 'clearlogo': video['logo']})
            url = G.get_plugin_url({'action': 'tv_play', 'cmd': video['cmd'], 'use_http_tmp_link': video.get('use_http_tmp_link', 0), 'use_load_balancing': video.get('use_load_balancing', 0)})
            directory_items.append((url, list_item, False))
        total_items = get_int_value(videos, 'total_items')
        if total_items > item_count:
            StalkerAddon.__add_navigation_items(params, videos, directory_items)
            item_count = item_count + 2
        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, item_count)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=update_listing == 'True', cacheToDisc=False)

    @staticmethod
    def __list_vod(params):
        """List videos for a category"""
        Logger.debug('List VOD {}'.format(params))
        search_term = params.get('search_term', '')
        plugin_category = 'VOD - ' + params['category'] if params.get('fav', '0') != '1' else 'VOD - ' + params['category'] + ' - FAVORITES'
        xbmcplugin.setPluginCategory(G.get_handle(), plugin_category)
        xbmcplugin.setContent(G.get_handle(), 'videos')
        # page_size controls how many server pages are loaded at once:
        #   1 = ~20 items, 2 = ~40 items, 5 = ~100 items, 9999 = all at once.
        # When "all at once" + cache → instant from local cache.
        # Otherwise → pages are fetched from server.
        videos = None
        load_all = G.addon_config.max_page_limit >= 9999
        use_cache = G.addon_config.cache_enabled
        if load_all and use_cache and not search_term.strip() and str(params.get('fav', '0')) == '0':
            cached = StalkerCache(G.addon_config.token_path, cache_days=G.addon_config.stalker_cache_days).get_videos('vod', params['category_id'])
            if cached is not None:
                videos = {'data': cached, 'total_items': len(cached), 'max_page_items': len(cached)}
        if videos is None:
            videos = Api.get_videos(params['category_id'], params['page'], search_term, params.get('fav', 0))
        StalkerAddon.__create_video_listing(videos, params)

    @staticmethod
    def __list_vod_favorites(params):
        """List Favorites Channels"""
        Logger.debug('List VOD Favorites {}'.format(params))
        xbmcplugin.setPluginCategory(G.get_handle(), 'VOD FAVORITES')
        xbmcplugin.setContent(G.get_handle(), 'videos')
        videos = Api.get_vod_favorites(params['page'])
        StalkerAddon.__create_video_listing(videos, params)

    @staticmethod
    def __list_series_favorites(params):
        """List Favorites Channels"""
        xbmcplugin.setPluginCategory(G.get_handle(), 'SERIES FAVORITES')
        xbmcplugin.setContent(G.get_handle(), 'videos')
        series = Api.get_series_favorites(params['page'])
        StalkerAddon.__create_series_listing(series, params)

    @staticmethod
    def __list_tv_favorites(params):
        """List Favorites Channels"""
        Logger.debug('List TV favorites {}'.format(params))
        xbmcplugin.setPluginCategory(G.get_handle(), 'TV FAVORITES')
        xbmcplugin.setContent(G.get_handle(), 'videos')
        videos = Api.get_tv_favorites(params['page'])
        StalkerAddon.__create_tv_listing(videos, params)

    @staticmethod
    def __list_series(params):
        """List series"""
        Logger.debug('List TV favorites {}'.format(params))
        search_term = params.get('search_term', '')
        plugin_category = 'SERIES - ' + params['category'] if params.get('fav', '0') != '1' else 'SERIES - ' + params['category'] + ' - FAVORITES'
        xbmcplugin.setPluginCategory(G.get_handle(), plugin_category)
        xbmcplugin.setContent(G.get_handle(), 'videos')
        # page_size controls how many server pages are loaded at once:
        #   1 = ~20 items, 2 = ~40 items, 5 = ~100 items, 9999 = all at once.
        # When "all at once" + cache → instant from local cache.
        # Otherwise → pages are fetched from server.
        series = None
        load_all = G.addon_config.max_page_limit >= 9999
        use_cache = G.addon_config.cache_enabled
        if load_all and use_cache and not search_term.strip() and str(params.get('fav', '0')) == '0':
            cached = StalkerCache(G.addon_config.token_path, cache_days=G.addon_config.stalker_cache_days).get_videos('series', params['category_id'])
            if cached is not None:
                series = {'data': cached, 'total_items': len(cached), 'max_page_items': len(cached)}
        if series is None:
            series = Api.get_series(params['category_id'], params['page'], search_term, params.get('fav', 0))
        StalkerAddon.__create_series_listing(series, params)

    @staticmethod
    def __list_season(params):
        """List season"""
        xbmcplugin.setPluginCategory(G.get_handle(), params['name'])
        xbmcplugin.setContent(G.get_handle(), 'videos')
        seasons = Api.get_seasons(params['video_id'])
        directory_items = []
        for season in seasons['data']:
            label = season['name']
            list_item = xbmcgui.ListItem(label=label, label2=label)
            match = re.match("^Season [0-9]+$", season['name'])
            name = params['name'] + ' ' + season['name']
            if match:
                temp = season['name'].split(' ')
                name = params['name'] + ' S' + temp[-1]
            url = G.get_plugin_url({'action': 'sub_folder', 'video_id': season['id'], 'start': season['series'][0],
                                    'end': season['series'][-1], 'name': name, 'poster_url': params['poster_url']})
            video_info = list_item.getVideoInfoTag()
            video_info.setMediaType('season')
            video_info.setTitle(season['name'])
            video_info.setOriginalTitle(season['name'])
            video_info.setSortTitle(season['name'])
            video_info.setPlot(season.get('description', ''))
            video_info.setPlotOutline(season.get('description', ''))
            actors = [xbmc.Actor(actor) for actor in season['actors'].split(',') if actor]  # pylint: disable=maybe-no-member
            video_info.setCast(actors)
            list_item.setArt({'poster': params['poster_url']})
            directory_items.append((url, list_item, True))
        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, len(seasons['data']))
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __create_video_listing(videos, params):
        """Create paginated listing"""
        update_listing = params['update_listing']
        item_count = len(videos['data'])
        directory_items = []
        for video in videos['data']:
            name = _clean_lang_tags(video['name'])
            label = name if video.get('hd', 1) == 1 else name + ' (SD)'
            if video.get('fav', 0) == 1:
                label = label + ' ★'
            list_item = xbmcgui.ListItem(label=label, label2=label)
            if video.get('fav', 0) == 1:
                url = G.get_plugin_url({'action': 'remove_fav', 'video_id': video['id'], '_type': 'vod'})
                list_item.addContextMenuItems([('Remove from favorites', f'RunPlugin({url}, False)')])
            else:
                url = G.get_plugin_url({'action': 'add_fav', 'video_id': video['id'], '_type': 'vod'})
                list_item.addContextMenuItems([('Add to favorites', f'RunPlugin({url}, False)')])

            is_folder = False
            poster_url = None
            if 'screenshot_uri' in video and isinstance(video['screenshot_uri'], str):
                if video['screenshot_uri'].startswith('http'):
                    poster_url = video['screenshot_uri']
                else:
                    poster_url = G.portal_config.portal_base_url + video['screenshot_uri']
            video_info = list_item.getVideoInfoTag()
            if video['series']:
                url = G.get_plugin_url({'action': 'sub_folder', 'video_id': video['id'], 'start': video['series'][0], 'end': video['series'][-1],
                                        'name': name, 'poster_url': poster_url})
                is_folder = True
                video_info.setMediaType('season')
            else:
                url = G.get_plugin_url({'action': 'play', 'video_id': video['id'], 'series': 0, 'title': name, 'cmd': video.get('cmd', '')})
                time = get_int_value(video, 'time')
                if time != 0:
                    video_info.setDuration(time * 60)
                video_info.setMediaType('movie')
                list_item.setProperty('IsPlayable', 'true')

            video_info.setTitle(name)
            video_info.setOriginalTitle(name)
            video_info.setSortTitle(name)
            if 'country' in video:
                video_info.setCountries([video['country']])
            video_info.setDirectors([video['director']])
            video_info.setPlot(video.get('description', ''))
            video_info.setPlotOutline(video.get('description', ''))
            actors = [xbmc.Actor(actor) for actor in video['actors'].split(',') if actor]  # pylint: disable=maybe-no-member
            video_info.setCast(actors)
            video_info.setLastPlayed(video['last_played'])
            video_info.setDateAdded(video['added'])
            year = get_int_value(video, 'year')
            if year != 0:
                video_info.setYear(year)
            # TMDB enrichment: overrides poster, fanart, plot, rating if available
            if video['series']:
                _apply_tmdb_tv(list_item, video_info, name, year if year != 0 else None, poster_url)
            else:
                _apply_tmdb_movie(list_item, video_info, name, year if year != 0 else None, poster_url)
            directory_items.append((url, list_item, is_folder))
        # Add navigation items
        total_items = get_int_value(videos, 'total_items')
        if total_items > item_count:
            StalkerAddon.__add_navigation_items(params, videos, directory_items)
            item_count = item_count + 2
        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, item_count)
        # Persist TMDB cache once for all films (instead of once per film)
        tmdb = _get_tmdb_client()
        if tmdb:
            tmdb.flush()
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=update_listing == 'True', cacheToDisc=False)

    @staticmethod
    def __create_series_listing(series, params):
        """Create paginated listing"""
        update_listing = params['update_listing']
        item_count = len(series['data'])
        directory_items = []
        for video in series['data']:
            name = _clean_lang_tags(video['name'])
            label = name if video.get('hd', 1) == 1 else name + ' (SD)'
            if video.get('fav', 0) == 1:
                label = label + ' ★'
            list_item = xbmcgui.ListItem(label=label, label2=label)
            if video.get('fav', 0) == 1:
                url = G.get_plugin_url({'action': 'remove_fav', 'video_id': video['id'], '_type': 'series'})
                list_item.addContextMenuItems([('Remove from favorites', f'RunPlugin({url}, False)')])
            else:
                url = G.get_plugin_url({'action': 'add_fav', 'video_id': video['id'], '_type': 'series'})
                list_item.addContextMenuItems([('Add to favorites', f'RunPlugin({url}, False)')])

            poster_url = None
            if 'screenshot_uri' in video and isinstance(video['screenshot_uri'], str):
                if video['screenshot_uri'].startswith('http'):
                    poster_url = video['screenshot_uri']
                else:
                    poster_url = G.portal_config.portal_base_url + video['screenshot_uri']
            video_info = list_item.getVideoInfoTag()
            url = G.get_plugin_url({'action': 'season_listing', 'video_id': video['id'], 'name': name, 'poster_url': poster_url})
            video_info.setMediaType('season')

            video_info.setTitle(name)
            video_info.setOriginalTitle(name)
            video_info.setSortTitle(name)
            if 'country' in video:
                video_info.setCountries([video['country']])
            video_info.setDirectors([video['director']])
            video_info.setPlot(video.get('description', ''))
            video_info.setPlotOutline(video.get('description', ''))
            actors = [xbmc.Actor(actor) for actor in video['actors'].split(',') if actor]  # pylint: disable=maybe-no-member
            video_info.setCast(actors)
            video_info.setLastPlayed(video['last_played'])
            video_info.setDateAdded(video['added'])
            year = get_int_value(video, 'year')
            if year != 0:
                video_info.setYear(year)
            # TMDB enrichment: overrides poster, fanart, plot, rating if available
            _apply_tmdb_tv(list_item, video_info, name, year if year != 0 else None, poster_url)
            directory_items.append((url, list_item, True))
        # Add navigation items
        total_items = get_int_value(series, 'total_items')
        if total_items > item_count:
            StalkerAddon.__add_navigation_items(params, series, directory_items)
            item_count = item_count + 2
        xbmcplugin.addDirectoryItems(G.get_handle(), directory_items, item_count)
        # Persist TMDB cache once for all series (instead of once per entry)
        tmdb = _get_tmdb_client()
        if tmdb:
            tmdb.flush()
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=update_listing == 'True',
                                  cacheToDisc=False)

    @staticmethod
    def __add_navigation_items(params, videos, directory_items):
        """Add navigation list items"""
        page = int(params['page'])
        total_items = get_int_value(videos, 'total_items')
        max_page_items = get_int_value(videos, 'max_page_items')
        total_pages = int(math.ceil(float(total_items) / float(max_page_items)))
        _max_page_limit = G.addon_config.max_page_limit
        if _max_page_limit > 1:
            total_pages = total_pages if (total_pages % _max_page_limit) == 0 else total_pages + _max_page_limit - (
                    total_pages % _max_page_limit)
        label = '<< Last Page' if page == 1 else '<< Previous Page'
        list_item = xbmcgui.ListItem(label)
        list_item.setArt({'thumb': G.get_custom_thumb_path('pagePrevious.png')})
        list_item.setProperty('specialsort', 'top')
        prev_page = total_pages - _max_page_limit + 1 if page == 1 else page - _max_page_limit
        params.update({'page': prev_page, 'update_listing': True})
        url = G.get_plugin_url(params)
        directory_items.insert(0, (url, list_item, True))

        label = 'First Page >>' if page == total_pages - _max_page_limit + 1 else 'Next Page >>'
        list_item = xbmcgui.ListItem(label)
        list_item.setArt({'thumb': G.get_custom_thumb_path('pageNext.png')})
        list_item.setProperty('specialsort', 'bottom')
        next_page = 1 if page == total_pages - _max_page_limit + 1 else page + _max_page_limit
        params.update({'page': next_page, 'update_listing': True})
        url = G.get_plugin_url(params)
        directory_items.append((url, list_item, True))

    @staticmethod
    def __list_episodes(params):
        """List episodes for a series"""
        name = params['name']
        xbmcplugin.setPluginCategory(G.get_handle(), name)
        xbmcplugin.setContent(G.get_handle(), 'videos')
        temp = name.split(' ')
        match = re.match("^S[0-9]+$", temp[-1])
        season = None
        if match:
            season = int(match.string[1:])
            name = ' '.join(temp[:-1])
        start = get_int_value(params, 'start')
        end = get_int_value(params, 'end')
        for episode_no in range(start, end + 1):
            list_item = xbmcgui.ListItem(label='Episode ' + str(episode_no))
            video_info = list_item.getVideoInfoTag()
            video_info.setTitle(name)
            video_info.setOriginalTitle(name)
            if match:
                video_info.setEpisode(episode_no)
                video_info.setSeason(season)
                video_info.setSortSeason(season)
                video_info.setMediaType('episode')
                video_info.setTvShowTitle(name)
            else:
                video_info.setMediaType('movie')
            list_item.setProperties({'IsPlayable': 'true'})
            list_item.setArt({'poster': params['poster_url']})
            url = G.get_plugin_url({'action': 'play', 'video_id': params['video_id'], 'series': episode_no, 'season_no': season,
                                    'title': name, 'total_episodes': end, 'poster_url': params['poster_url']})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, False)
        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    def __search_vod(self, params):
        """Search for videos"""
        Logger.debug('Search VOD {}'.format(params))

        # Wenn keine Kategorie angegeben → direkt alle sichtbaren Gruppen durchsuchen
        if not params.get('category'):
            search_term = ask_for_input('Alle Kategorien')
            if search_term:
                all_categories = Api.get_vod_categories()
                filtered_categories = _apply_category_filter(all_categories, G.get_filter_file_path('vod'))
                self.__search_vod_across_categories(filtered_categories, search_term, params)
            else:
                xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)
            return

        # Kontextmenü-Suche: Kategorie ist bereits gesetzt → nur in dieser Kategorie suchen
        search_term = ask_for_input(params['category'])
        if search_term:
            params.update({'action': 'vod_listing', 'update_listing': False, 'search_term': search_term, 'page': 1})
            is_context = str(params.get('isContextMenuSearch', 'true')).lower() == 'true'
            if is_context:
                url = G.get_plugin_url(params)
                func_str = f'Container.Update({url})'
                xbmc.executebuiltin(func_str)
            else:
                self.__list_vod(params)

    def __search_vod_across_categories(self, filtered_categories, search_term, params):
        """Suche über alle sichtbaren VOD-Kategorien und zeige kombinierte Ergebnisse."""
        all_videos = {'data': [], 'total_items': 0, 'max_page_items': 9999}
        for category in filtered_categories:
            try:
                result = Api.get_videos(category['id'], 1, search_term, 0)
                all_videos['data'].extend(result.get('data', []))
            except Exception:
                pass
        all_videos['total_items'] = len(all_videos['data'])
        params.update({'category': 'Alle Kategorien', 'update_listing': False, 'fav': '0', 'page': 1})
        StalkerAddon.__create_video_listing(all_videos, params)

    def __search_series(self, params):
        """Search for videos"""

        # Wenn keine Kategorie angegeben → direkt alle sichtbaren Gruppen durchsuchen
        if not params.get('category'):
            search_term = ask_for_input('Alle Kategorien')
            if search_term:
                raw = Api.get_series_categories()
                all_categories = raw if isinstance(raw, list) else []
                filtered_categories = _apply_category_filter(all_categories, G.get_filter_file_path('series'))
                self.__search_series_across_categories(filtered_categories, search_term, params)
            else:
                xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)
            return

        # Kontextmenü-Suche: Kategorie ist bereits gesetzt → nur in dieser Kategorie suchen
        search_term = ask_for_input(params['category'])
        if search_term:
            params.update({'action': 'series_listing', 'update_listing': False, 'search_term': search_term, 'page': 1})
            url = G.get_plugin_url(params)
            func_str = f'Container.Update({url})'
            xbmc.executebuiltin(func_str)

    def __search_series_across_categories(self, filtered_categories, search_term, params):
        """Suche über alle sichtbaren Serien-Kategorien und zeige kombinierte Ergebnisse."""
        all_series = {'data': [], 'total_items': 0, 'max_page_items': 9999}
        for category in filtered_categories:
            try:
                result = Api.get_series(category['id'], 1, search_term, 0)
                all_series['data'].extend(result.get('data', []))
            except Exception:
                pass
        all_series['total_items'] = len(all_series['data'])
        params.update({'category': 'Alle Kategorien', 'update_listing': False, 'fav': '0', 'page': 1})
        StalkerAddon.__create_series_listing(all_series, params)

    def __search_tv(self, params):
        """Search for videos"""

        # Wenn keine Kategorie angegeben → direkt alle sichtbaren Genres durchsuchen
        if not params.get('category'):
            search_term = ask_for_input('Alle Genres')
            if search_term:
                all_genres = Api.get_tv_genres()
                filtered_genres = _apply_category_filter(all_genres, G.get_filter_file_path('tv'))
                self.__search_tv_across_genres(filtered_genres, search_term, params)
            else:
                xbmcplugin.endOfDirectory(G.get_handle(), succeeded=False, updateListing=False, cacheToDisc=False)
            return

        # Kontextmenü-Suche: Kategorie ist bereits gesetzt → nur in diesem Genre suchen
        search_term = ask_for_input(params['category'])
        if search_term:
            params.update({'action': 'tv_listing', 'update_listing': False, 'search_term': search_term, 'page': 1})
            is_context = str(params.get('isContextMenuSearch', 'true')).lower() == 'true'
            if is_context:
                url = G.get_plugin_url(params)
                func_str = f'Container.Update({url})'
                xbmc.executebuiltin(func_str)
            else:
                self.__list_channels(params)

    def __search_tv_across_genres(self, filtered_genres, search_term, params):
        """Suche über alle sichtbaren TV-Genres und zeige kombinierte Ergebnisse."""
        all_channels = {'data': [], 'total_items': 0, 'max_page_items': 9999}
        for genre in filtered_genres:
            try:
                result = Api.get_tv_channels(genre['id'], 1, search_term, 0)
                all_channels['data'].extend(result.get('data', []))
            except Exception:
                pass
        all_channels['total_items'] = len(all_channels['data'])
        params.update({'category': 'Alle Genres', 'update_listing': False, 'fav': '0', 'page': 1})
        StalkerAddon.__create_tv_listing(all_channels, params)

    @staticmethod
    def __list_main_menu():
        """List main menu"""
        list_item = xbmcgui.ListItem(label='TV CHANNELS')
        url = G.get_plugin_url({'action': 'tv', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        list_item = xbmcgui.ListItem(label='VOD')
        url = G.get_plugin_url({'action': 'vod', 'page': 1, 'update_listing': False})
        xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        series_categories = Api.get_series_categories()
        if isinstance(series_categories, list) and len(series_categories) > 0:
            list_item = xbmcgui.ListItem(label='SERIES')
            url = G.get_plugin_url({'action': 'series', 'page': 1, 'update_listing': False})
            xbmcplugin.addDirectoryItem(G.get_handle(), url, list_item, True)

        xbmcplugin.endOfDirectory(G.get_handle(), succeeded=True, updateListing=False, cacheToDisc=False)

    @staticmethod
    def __refresh_all_data(silent=False):
        """Pre-fetch all VOD/Series categories and video lists.

        Saves results to the local Stalker cache (always) and warms the
        TMDB cache if TMDB is enabled.

        silent=True: no progress dialog, runs as background task (triggered
        by the daily service check on Kodi start).
        """
        # Prevent screensaver from interrupting the refresh (e.g. Nvidia Shield)
        xbmc.executebuiltin('InhibitScreensaver(true)')
        stalker_cache = StalkerCache(G.addon_config.token_path, cache_days=G.addon_config.stalker_cache_days)
        progress = None
        if not silent:
            progress = xbmcgui.DialogProgress()
            progress.create('Stalker VOD', 'Kategorien werden geladen...')
        try:
            original_limit = G.addon_config.max_page_limit
            G.addon_config.max_page_limit = 9999

            # --- Fetch and cache category lists ---
            vod_cats = []
            series_cats = []
            try:
                vod_cats = Api.get_vod_categories() or []
                stalker_cache.set_categories('vod', vod_cats)
            except Exception:
                pass
            try:
                raw = Api.get_series_categories()
                series_cats = raw if isinstance(raw, list) else []
                stalker_cache.set_categories('series', series_cats)
            except Exception:
                pass

            # Apply folder filter so only visible folders are refreshed
            vod_cats = _apply_category_filter(vod_cats, G.get_filter_file_path('vod'))
            series_cats = _apply_category_filter(series_cats, G.get_filter_file_path('series'))

            work = [('vod', c) for c in vod_cats] + [('series', c) for c in series_cats]
            total = len(work)
            if total == 0:
                if not silent:
                    xbmcgui.Dialog().ok('Stalker VOD', 'Keine Kategorien gefunden.')
                return

            tmdb = _get_tmdb_client()
            for idx, (cat_type, category) in enumerate(work):
                if not silent and progress.iscanceled():
                    break
                pct = int(idx * 100 / total)
                cat_name = category['title']
                if not silent:
                    progress.update(pct, '[{}/{}] {}'.format(idx + 1, total, cat_name))
                try:
                    if cat_type == 'vod':
                        result = Api.get_videos(category['id'], 1, '', 0)
                    else:
                        result = Api.get_series(category['id'], 1, '', 0)
                except Exception:
                    continue

                # Save video list to local Stalker cache
                stalker_cache.set_videos(cat_type, category['id'], result.get('data', []))

                if tmdb:
                    rate_limit_hit = False
                    for video in result.get('data', []):
                        if not silent and progress.iscanceled():
                            break
                        vname = _clean_lang_tags(video['name'])
                        if not silent:
                            progress.update(pct, '[{}/{}] {}: {}'.format(idx + 1, total, cat_name, vname))
                        year = get_int_value(video, 'year')
                        year = year if year != 0 else None
                        try:
                            if cat_type == 'series' or video.get('series'):
                                tmdb.get_tv_info(vname, year)
                            else:
                                tmdb.get_movie_info(vname, year)
                        except TmdbRateLimitError:
                            rate_limit_hit = True
                            break
                    tmdb.flush()
                    if rate_limit_hit:
                        G.addon_config.max_page_limit = original_limit
                        if not silent and progress:
                            progress.close()
                        if not silent:
                            xbmcgui.Dialog().ok(
                                'Stalker VOD – TMDB abgebrochen',
                                'TMDB hat zu viele Anfragen in Folge blockiert.[CR][CR]'
                                'Der Download wurde sicherheitshalber gestoppt.[CR]'
                                'Die bereits geladenen Daten wurden gespeichert.[CR][CR]'
                                'Bitte warte einige Minuten und versuche es erneut.'
                            )
                        return

            G.addon_config.max_page_limit = original_limit
            if not silent and not progress.iscanceled():
                progress.update(100, 'Aktualisierung abgeschlossen!')
                xbmc.sleep(1500)
        finally:
            xbmc.executebuiltin('InhibitScreensaver(false)')
            if not silent and progress:
                progress.close()

    @staticmethod
    def __update_new_data(silent=False):
        """Load portal data to cache (smart update).

        Downloads all film/series data from the portal and saves it locally.
        Existing cached items are kept untouched – only new items are added.
        TMDB metadata is only fetched for genuinely new films.
        If TMDB is disabled or no key is set, the TMDB step is simply skipped.

        silent=True: no progress dialog, runs as background task (triggered
        by the automatic cache refresh on Kodi start).
        """
        # Prevent screensaver from interrupting the update (e.g. Nvidia Shield)
        xbmc.executebuiltin('InhibitScreensaver(true)')
        stalker_cache = StalkerCache(G.addon_config.token_path, cache_days=G.addon_config.stalker_cache_days)
        progress = None
        if not silent:
            progress = xbmcgui.DialogProgress()
            progress.create('Stalker VOD', 'Kategorien werden geladen...')
        try:
            original_limit = G.addon_config.max_page_limit
            G.addon_config.max_page_limit = 9999

            # --- Fetch and cache category lists ---
            vod_cats = []
            series_cats = []
            try:
                vod_cats = Api.get_vod_categories() or []
                stalker_cache.set_categories('vod', vod_cats)
            except Exception:
                pass
            try:
                raw = Api.get_series_categories()
                series_cats = raw if isinstance(raw, list) else []
                stalker_cache.set_categories('series', series_cats)
            except Exception:
                pass

            # Apply folder filter so only visible folders are processed
            vod_cats = _apply_category_filter(vod_cats, G.get_filter_file_path('vod'))
            series_cats = _apply_category_filter(series_cats, G.get_filter_file_path('series'))

            work = [('vod', c) for c in vod_cats] + [('series', c) for c in series_cats]
            total = len(work)
            if total == 0:
                if not silent:
                    xbmcgui.Dialog().ok('Stalker VOD', 'Keine Kategorien gefunden.')
                return

            tmdb = _get_tmdb_client()
            total_new = 0
            for idx, (cat_type, category) in enumerate(work):
                if not silent and progress.iscanceled():
                    break
                pct = int(idx * 100 / total)
                cat_name = category['title']
                if not silent:
                    progress.update(pct, '[{}/{}] {}'.format(idx + 1, total, cat_name))
                try:
                    if cat_type == 'vod':
                        result = Api.get_videos(category['id'], 1, '', 0)
                    else:
                        result = Api.get_series(category['id'], 1, '', 0)
                except Exception:
                    continue

                server_items = result.get('data', [])
                cached_items = stalker_cache.get_videos(cat_type, category['id']) or []
                cached_ids = {str(v.get('id', '')) for v in cached_items}

                # Only process films not yet in cache
                new_items = [v for v in server_items if str(v.get('id', '')) not in cached_ids]
                if not new_items:
                    # Even if no new items, save the video list to refresh the cache timestamp
                    stalker_cache.set_videos(cat_type, category['id'], cached_items)
                    continue

                # New items first so they appear at the top
                merged = new_items + cached_items
                stalker_cache.set_videos(cat_type, category['id'], merged)
                total_new += len(new_items)

                if tmdb:
                    rate_limit_hit = False
                    for video in new_items:
                        if not silent and progress.iscanceled():
                            break
                        vname = _clean_lang_tags(video['name'])
                        if not silent:
                            progress.update(pct, '[{}/{}] {}: {}'.format(idx + 1, total, cat_name, vname))
                        year = get_int_value(video, 'year')
                        year = year if year != 0 else None
                        try:
                            if cat_type == 'series' or video.get('series'):
                                tmdb.get_tv_info(vname, year)
                            else:
                                tmdb.get_movie_info(vname, year)
                        except TmdbRateLimitError:
                            rate_limit_hit = True
                            break
                    tmdb.flush()
                    if rate_limit_hit:
                        G.addon_config.max_page_limit = original_limit
                        if not silent and progress:
                            progress.close()
                        if not silent:
                            xbmcgui.Dialog().ok(
                                'Stalker VOD – TMDB abgebrochen',
                                'TMDB hat zu viele Anfragen in Folge blockiert.[CR][CR]'
                                'Der Download wurde sicherheitshalber gestoppt.[CR]'
                                'Die bereits geladenen Daten wurden gespeichert.[CR][CR]'
                                'Bitte warte einige Minuten und versuche es erneut.'
                            )
                        return

            G.addon_config.max_page_limit = original_limit
            if not silent and not progress.iscanceled():
                progress.update(100, '{} neue Inhalte hinzugefügt.'.format(total_new))
                xbmc.sleep(1500)
        finally:
            xbmc.executebuiltin('InhibitScreensaver(false)')
            if not silent and progress:
                progress.close()

    @staticmethod
    def __manage_folder_selection(params):
        """Open a multiselect dialog so the user can pick which folders are visible.

        Triggered via action=manage_folders&type=vod|series|tv.
        Saves the selected IDs as JSON to the profile directory.
        """
        cat_type = params.get('type', 'vod')
        filter_file = G.get_filter_file_path(cat_type)

        if cat_type == 'vod':
            categories = Api.get_vod_categories() or []
            heading = 'VOD-Ordner auswählen'
        elif cat_type == 'series':
            raw = Api.get_series_categories()
            categories = raw if isinstance(raw, list) else []
            heading = 'Serien-Ordner auswählen'
        else:
            categories = Api.get_tv_genres() or []
            heading = 'TV-Genres auswählen'

        if not categories:
            xbmcgui.Dialog().ok('Stalker VOD', 'Keine Ordner gefunden. Bitte prüfe die Serververbindung.')
            return

        names = [c['title'] for c in categories]

        # Load previously saved selection; if no file yet → start with nothing selected
        file_exists, stored_ids = _load_filter_ids(filter_file)
        if file_exists and stored_ids:
            preselected = [i for i, c in enumerate(categories) if str(c['id']) in stored_ids]
        else:
            preselected = []  # First time: nothing checked → user selects what they want

        selected_indices = xbmcgui.Dialog().multiselect(heading, names, preselect=preselected)

        if selected_indices is None:
            return  # User cancelled → keep existing setting unchanged

        selected_ids = [str(categories[i]['id']) for i in selected_indices]
        _save_filter_ids(filter_file, selected_ids)

        count_visible = len(selected_ids)
        count_total = len(categories)
        xbmcgui.Dialog().ok(
            'Stalker VOD',
            '{} von {} Ordnern werden angezeigt.'.format(count_visible, count_total))

    @staticmethod
    def __tmdb_refresh_now():
        """Fetch TMDB metadata for all films already in the local Stalker cache.

        Does NOT re-download Stalker data – only fills/updates the TMDB cache.
        Skips films whose TMDB entry is still fresh.
        """
        tmdb = _get_tmdb_client()
        if tmdb is None:
            xbmcgui.Dialog().ok(
                'Stalker VOD',
                'TMDB ist nicht aktiviert oder kein API-Key eingegeben.[CR]'
                'Bitte TMDB zuerst im TMDB-Tab einrichten.'
            )
            return

        stalker_cache = StalkerCache(G.addon_config.token_path, cache_days=G.addon_config.stalker_cache_days)
        vod_cats = _apply_category_filter(
            stalker_cache.get_categories('vod') or [],
            G.get_filter_file_path('vod')
        )
        series_cats = _apply_category_filter(
            stalker_cache.get_categories('series') or [],
            G.get_filter_file_path('series')
        )
        work = [('vod', c) for c in vod_cats] + [('series', c) for c in series_cats]
        total = len(work)

        if total == 0:
            xbmcgui.Dialog().ok(
                'Stalker VOD',
                'Kein lokaler Stalker-Cache vorhanden.[CR]'
                'Erst "Alle Daten aktualisieren" im Cache-Tab ausführen.'
            )
            return

        # Prevent screensaver from interrupting the TMDB refresh
        xbmc.executebuiltin('InhibitScreensaver(true)')
        progress = xbmcgui.DialogProgress()
        progress.create('TMDB-Metadaten laden', 'Starte...')
        try:
            for idx, (cat_type, category) in enumerate(work):
                if progress.iscanceled():
                    break
                pct = int(idx * 100 / total)
                cat_name = category['title']
                progress.update(pct, '[{}/{}] {}'.format(idx + 1, total, cat_name))
                videos = stalker_cache.get_videos(cat_type, category['id']) or []
                rate_limit_hit = False
                for video in videos:
                    if progress.iscanceled():
                        break
                    vname = _clean_lang_tags(video['name'])
                    progress.update(pct, '[{}/{}] {}: {}'.format(idx + 1, total, cat_name, vname))
                    year = get_int_value(video, 'year')
                    year = year if year != 0 else None
                    try:
                        if cat_type == 'series' or video.get('series'):
                            tmdb.get_tv_info(vname, year)
                        else:
                            tmdb.get_movie_info(vname, year)
                    except TmdbRateLimitError:
                        rate_limit_hit = True
                        break
                tmdb.flush()
                if rate_limit_hit:
                    progress.close()
                    xbmcgui.Dialog().ok(
                        'Stalker VOD – TMDB abgebrochen',
                        'TMDB hat zu viele Anfragen in Folge blockiert.[CR][CR]'
                        'Der Download wurde sicherheitshalber gestoppt.[CR]'
                        'Die bereits geladenen Daten wurden gespeichert.[CR][CR]'
                        'Bitte warte einige Minuten und versuche es erneut.'
                    )
                    return
            if not progress.iscanceled():
                progress.update(100, 'TMDB-Metadaten vollständig geladen!')
                xbmc.sleep(1500)
        finally:
            xbmc.executebuiltin('InhibitScreensaver(false)')
            progress.close()

    @staticmethod
    def __tmdb_clear_cache():
        """Delete the local TMDB cache file."""
        cache_path = os.path.join(G.addon_config.token_path, 'tmdb_cache.json')
        if not xbmcvfs.exists(cache_path):
            xbmcgui.Dialog().ok('TMDB-Cache', 'Kein Cache vorhanden – nichts zu löschen.')
            return
        confirmed = xbmcgui.Dialog().yesno(
            'TMDB-Cache löschen',
            'Soll der TMDB-Cache wirklich gelöscht werden?[CR][CR]'
            'Beim nächsten Öffnen eines Ordners werden alle TMDB-Daten '
            '(Poster, Beschreibungen, Bewertungen) neu heruntergeladen.'
        )
        if not confirmed:
            return
        if xbmcvfs.delete(cache_path):
            xbmcgui.Dialog().ok(
                'TMDB-Cache gelöscht',
                'Der TMDB-Cache wurde gelöscht.[CR]'
                'Beim nächsten Öffnen eines Ordners werden die Daten neu heruntergeladen.'
            )
        else:
            xbmcgui.Dialog().ok('TMDB-Cache', 'Fehler: Cache konnte nicht gelöscht werden.')

    # ------------------------------------------------------------------
    # Stalker Portal Cache Management
    # ------------------------------------------------------------------

    @staticmethod
    def __stalker_cache_info():
        """Show Stalker portal cache statistics: number of files, total size, age."""
        cache_dir = G.addon_config.token_path
        if not cache_dir:
            xbmcgui.Dialog().ok('Portal-Cache Info', 'Kein Cache-Verzeichnis konfiguriert.')
            return

        import glob as globmod
        pattern = os.path.join(cache_dir, 'stalker_*.json')
        cache_files = globmod.glob(pattern)

        if not cache_files:
            xbmcgui.Dialog().ok(
                'Portal-Cache Info',
                'Kein Portal-Cache vorhanden.[CR]'
                'Erst "Alle Daten aktualisieren" ausführen.'
            )
            return

        total_size = 0
        oldest_ts = None
        newest_ts = None
        cat_count = 0
        video_count = 0

        for fp in cache_files:
            try:
                stat = xbmcvfs.Stat(fp)
                total_size += stat.st_size()
            except Exception:
                pass

            try:
                with xbmcvfs.File(fp, 'r') as fh:
                    content = fh.read()
                if content:
                    data = json.loads(content)
                    ts = data.get('ts', 0)
                    if ts > 0:
                        if oldest_ts is None or ts < oldest_ts:
                            oldest_ts = ts
                        if newest_ts is None or ts > newest_ts:
                            newest_ts = ts
                    fname = os.path.basename(fp)
                    if fname.startswith('stalker_cats_'):
                        cat_count += len(data.get('data', []))
                    elif fname.startswith('stalker_videos_'):
                        video_count += len(data.get('data', []))
            except Exception:
                pass

        now = time.time()
        if total_size < 1024 * 1024:
            size_str = '{:.0f} KB'.format(total_size / 1024.0)
        else:
            size_str = '{:.2f} MB'.format(total_size / (1024.0 * 1024.0))

        if oldest_ts:
            oldest_days = int((now - oldest_ts) / 86400.0)
            oldest_str = 'heute' if oldest_days == 0 else 'vor {} Tag(en)'.format(oldest_days)
        else:
            oldest_str = 'unbekannt'

        if newest_ts:
            newest_days = int((now - newest_ts) / 86400.0)
            newest_str = 'heute' if newest_days == 0 else 'vor {} Tag(en)'.format(newest_days)
        else:
            newest_str = 'unbekannt'

        xbmcgui.Dialog().ok(
            'Portal-Cache Info',
            'Kategorien im Cache: {}[CR]'
            'Filme/Serien im Cache: {}[CR]'
            'Cache-Dateien: {}[CR]'
            'Neuester Eintrag: {}[CR]'
            'Ältester Eintrag: {}[CR]'
            'Cache-Größe: {}'.format(
                cat_count,
                video_count,
                len(cache_files),
                newest_str,
                oldest_str,
                size_str,
            )
        )

    @staticmethod
    def __stalker_clear_cache():
        """Delete all local Stalker portal cache files."""
        import glob as globmod
        cache_dir = G.addon_config.token_path
        pattern = os.path.join(cache_dir, 'stalker_*.json')
        cache_files = globmod.glob(pattern)

        if not cache_files:
            xbmcgui.Dialog().ok('Portal-Cache', 'Kein Cache vorhanden – nichts zu löschen.')
            return

        confirmed = xbmcgui.Dialog().yesno(
            'Portal-Cache löschen',
            'Soll der Portal-Cache wirklich gelöscht werden?[CR][CR]'
            'Beim nächsten Öffnen eines Ordners werden alle Daten '
            'neu vom Server geladen. Das kann einige Sekunden dauern.'
        )
        if not confirmed:
            return

        deleted = 0
        for fp in cache_files:
            try:
                if xbmcvfs.delete(fp):
                    deleted += 1
            except Exception:
                pass

        xbmcgui.Dialog().ok(
            'Portal-Cache gelöscht',
            '{} Cache-Datei(en) gelöscht.[CR]'
            'Beim nächsten Öffnen eines Ordners werden die Daten '
            'neu vom Server geladen.'.format(deleted)
        )

    # ------------------------------------------------------------------
    # TMDB Filter (Genre / Year / Rating)
    # ------------------------------------------------------------------

    def __vod_filter(self, params):
        """Entry point for VOD filter (action=vod_filter)."""
        self.__run_filter('vod', params)

    def __series_filter(self, params):
        """Entry point for Series filter (action=series_filter)."""
        self.__run_filter('series', params)

    def __run_filter(self, cat_type, params):
        """Main filter flow: collect data → dialog → display results."""
        tmdb = _get_tmdb_client()
        if tmdb is None:
            xbmcgui.Dialog().ok(
                'Stalker VOD',
                'Filter benötigt TMDB-Daten.[CR][CR]'
                'Bitte aktiviere TMDB in den Einstellungen,[CR]'
                'gib einen API-Key ein und führe[CR]'
                '"Alle Daten aktualisieren" aus.'
            )
            return

        # Collect all videos with their TMDB data from cache
        videos_with_tmdb, all_genres, all_years, all_ratings = self.__collect_filter_data(cat_type)

        if not videos_with_tmdb:
            xbmcgui.Dialog().ok(
                'Stalker VOD',
                'Keine TMDB-Daten im Cache gefunden.[CR][CR]'
                'Bitte führe zuerst "Alle Daten aktualisieren"[CR]'
                'in den Einstellungen aus.'
            )
            return

        # Show filter type selection
        filter_labels = ['Genre', 'Jahr / Jahrzehnt', 'Mindestbewertung', 'Alle Kriterien (Kombination)']
        choice = xbmcgui.Dialog().select('Filtern nach:', filter_labels)
        if choice < 0:
            return

        selected_genres = None
        selected_year_range = None
        selected_min_rating = None

        if choice == 0:
            # Genre only
            selected_genres = self.__ask_genre_filter(all_genres)
            if selected_genres is None:
                return
        elif choice == 1:
            # Year only
            selected_year_range = self.__ask_year_filter(all_years)
            if selected_year_range is None:
                return
        elif choice == 2:
            # Rating only
            selected_min_rating = self.__ask_rating_filter()
            if selected_min_rating is None:
                return
        elif choice == 3:
            # Combination: all three steps
            selected_genres = self.__ask_genre_filter(all_genres)
            if selected_genres is None:
                return
            selected_year_range = self.__ask_year_filter(all_years)
            # Cancel on year/rating = skip that criterion (not abort)
            selected_min_rating = self.__ask_rating_filter()

        # Apply filters
        filtered = self.__apply_filters(
            videos_with_tmdb, selected_genres, selected_year_range, selected_min_rating
        )

        if not filtered:
            xbmcgui.Dialog().ok('Stalker VOD', 'Keine Filme gefunden die allen Kriterien entsprechen.')
            return

        # Build description for plugin category
        filter_desc = self.__build_filter_desc(selected_genres, selected_year_range, selected_min_rating)

        # Display as flat listing
        video_list = [v for v, _ in filtered]
        result = {'data': video_list, 'total_items': len(video_list), 'max_page_items': len(video_list)}
        label = 'VOD' if cat_type == 'vod' else 'SERIES'
        xbmcplugin.setPluginCategory(G.get_handle(), '{} FILTER: {}'.format(label, filter_desc))
        xbmcplugin.setContent(G.get_handle(), 'videos')
        if cat_type == 'vod':
            StalkerAddon.__create_video_listing(result, {
                'category': 'Filter: ' + filter_desc,
                'update_listing': False, 'fav': '0', 'page': 1
            })
        else:
            StalkerAddon.__create_series_listing(result, {
                'category': 'Filter: ' + filter_desc,
                'update_listing': False, 'fav': '0', 'page': 1
            })

    def __collect_filter_data(self, cat_type):
        """Load all cached videos and match with TMDB cache data.

        Returns (videos_with_tmdb, all_genres, all_years, all_ratings) where
        videos_with_tmdb is a list of (stalker_video, tmdb_info) tuples.
        """
        tmdb = _get_tmdb_client()
        stalker_cache = StalkerCache(G.addon_config.token_path, cache_days=G.addon_config.stalker_cache_days)
        raw_cats = stalker_cache.get_categories(cat_type) or []
        filter_file = G.get_filter_file_path(cat_type)
        categories = _apply_category_filter(raw_cats, filter_file)

        all_genres = set()
        all_years = set()
        all_ratings = set()
        videos_with_tmdb = []

        for category in categories:
            videos = stalker_cache.get_videos(cat_type, category['id'])
            if not videos:
                continue
            for video in videos:
                name = _clean_lang_tags(video['name'])
                year = get_int_value(video, 'year')
                year = year if year != 0 else None
                is_series = cat_type == 'series' or video.get('series')
                if is_series:
                    info = tmdb.get_cached_tv_info(name, year)
                else:
                    info = tmdb.get_cached_movie_info(name, year)
                if info is _CACHE_MISS or info is None:
                    continue
                videos_with_tmdb.append((video, info))
                for g in info.get('genres', []):
                    all_genres.add(g)
                if info.get('year') and info['year'] > 0:
                    all_years.add(info['year'])
                if info.get('rating') and info['rating'] > 0:
                    # Round to one decimal for grouping
                    all_ratings.add(round(info['rating'], 1))

        return videos_with_tmdb, sorted(all_genres), sorted(all_years, reverse=True), sorted(all_ratings, reverse=True)

    @staticmethod
    def __ask_genre_filter(all_genres):
        """Show genre multiselect dialog. Returns list of selected genres or None to abort."""
        if not all_genres:
            xbmcgui.Dialog().ok('Stalker VOD', 'Keine Genre-Daten im Cache vorhanden.')
            return None
        selected = xbmcgui.Dialog().multiselect('Genres wählen (mehrere möglich)', all_genres)
        if selected is None:
            return None
        return [all_genres[i] for i in selected]

    @staticmethod
    def __ask_year_filter(all_years):
        """Show year/decade selection dialog. Returns (min_year, max_year) tuple or None."""
        if not all_years:
            return None
        decade_options = [
            ('2020 – 2029', 2020, 2029),
            ('2010 – 2019', 2010, 2019),
            ('2000 – 2009', 2000, 2009),
            ('1990 – 1999', 1990, 1999),
            ('1980 – 1989', 1980, 1989),
            ('Vor 1980', 0, 1979),
        ]
        labels = [d[0] for d in decade_options]
        choice = xbmcgui.Dialog().select('Zeitraum wählen', labels)
        if choice < 0:
            return None
        return (decade_options[choice][1], decade_options[choice][2])

    @staticmethod
    def __ask_rating_filter():
        """Show minimum rating selection dialog. Returns float minimum or None."""
        options = [
            ('9+ (Herausragend)', 9.0),
            ('8+ (Sehr gut)', 8.0),
            ('7+ (Gut)', 7.0),
            ('6+ (Okay)', 6.0),
            ('5+ (Durchschnitt)', 5.0),
        ]
        labels = [o[0] for o in options]
        choice = xbmcgui.Dialog().select('Mindestbewertung', labels)
        if choice < 0:
            return None
        return options[choice][1]

    @staticmethod
    def __apply_filters(videos_with_tmdb, genres, year_range, min_rating):
        """Filter (video, tmdb_info) pairs based on selected criteria.

        All criteria use AND logic: a film must match ALL active filters.
        None for a criterion means "no filter" (match all).
        """
        result = []
        for video, info in videos_with_tmdb:
            # Genre filter: film must have at least one of the selected genres
            if genres:
                film_genres = info.get('genres', [])
                if not any(g in film_genres for g in genres):
                    continue
            # Year filter
            if year_range:
                film_year = info.get('year', 0)
                if not (year_range[0] <= film_year <= year_range[1]):
                    continue
            # Rating filter
            if min_rating is not None:
                film_rating = info.get('rating', 0)
                if film_rating < min_rating:
                    continue
            result.append((video, info))
        return result

    @staticmethod
    def __build_filter_desc(genres, year_range, min_rating):
        """Build a human-readable description of the active filter criteria."""
        parts = []
        if genres:
            if len(genres) <= 3:
                parts.append(', '.join(genres))
            else:
                parts.append('{} Genres'.format(len(genres)))
        if year_range:
            if year_range[0] == 0:
                parts.append('Vor {}'.format(year_range[1] + 1))
            else:
                parts.append('{}-{}'.format(year_range[0], year_range[1]))
        if min_rating is not None:
            parts.append('{}+'.format(int(min_rating)))
        return ' / '.join(parts) if parts else 'Alle'

    @staticmethod
    def __show_tmdb_cache_info():
        """Show TMDB cache statistics: entry count, age, expiry, file size."""
        import json
        cache_path = os.path.join(G.addon_config.token_path, 'tmdb_cache.json')
        cache_days = G.tmdb_config.cache_days

        if not xbmcvfs.exists(cache_path):
            xbmcgui.Dialog().ok(
                'TMDB-Cache Info',
                'Kein Cache vorhanden.[CR]'
                'Erst "Alle Daten aktualisieren" ausführen.'
            )
            return

        try:
            with xbmcvfs.File(cache_path, 'r') as fh:
                content = fh.read()
            cache = json.loads(content) if content else {}
        except Exception:
            xbmcgui.Dialog().ok('TMDB-Cache Info', 'Cache-Datei konnte nicht gelesen werden.')
            return

        now = time.time()
        genre_keys = {'__genres_movie__', '__genres_tv__'}
        film_entries = {k: v for k, v in cache.items() if k not in genre_keys and isinstance(v, dict)}

        if not film_entries:
            xbmcgui.Dialog().ok('TMDB-Cache Info', 'Cache ist leer.\nNoch keine TMDB-Daten heruntergeladen.')
            return

        timestamps = [v.get('ts', now) for v in film_entries.values()]
        oldest_ts = min(timestamps)
        newest_ts = max(timestamps)
        oldest_days = int((now - oldest_ts) / 86400.0)
        newest_days = int((now - newest_ts) / 86400.0)
        expires_in_days = cache_days - oldest_days

        if expires_in_days > 0:
            expiry_str = 'noch {} Tage'.format(expires_in_days)
        else:
            expiry_str = 'abgelaufen (wird beim nächsten Zugriff erneuert)'

        try:
            stat = xbmcvfs.Stat(cache_path)
            size_bytes = stat.st_size()
            if size_bytes < 1024 * 1024:
                size_str = '{:.0f} KB'.format(size_bytes / 1024.0)
            else:
                size_str = '{:.2f} MB'.format(size_bytes / (1024.0 * 1024.0))
        except Exception:
            size_str = 'unbekannt'

        newest_str = 'heute' if newest_days == 0 else 'vor {} Tag(en)'.format(newest_days)
        oldest_str = 'heute' if oldest_days == 0 else 'vor {} Tag(en)'.format(oldest_days)

        xbmcgui.Dialog().ok(
            'TMDB-Cache Info',
            'Gespeicherte Einträge: {} Filme[CR]'
            'Neuester Eintrag: {}[CR]'
            'Ältester Eintrag: {}[CR]'
            'Läuft ab in: {} (Einstellung: {} Tage)[CR]'
            'Cache-Größe: {}'.format(
                len(film_entries),
                newest_str,
                oldest_str,
                expiry_str,
                cache_days,
                size_str,
            )
        )

    def router(self, param_string):
        """Route calls"""
        params = dict(parse_qsl(param_string))
        if params and 'action' in params:
            if params['action'] == 'tv':
                self.__list_tv_genres()
            elif params['action'] == 'vod':
                self.__list_vod_categories()
            elif params['action'] == 'series':
                self.__list_series_categories()
            elif params['action'] == 'vod_favorites':
                self.__list_vod_favorites(params)
            elif params['action'] == 'series_favorites':
                self.__list_series_favorites(params)
            elif params['action'] == 'tv_favorites':
                self.__list_tv_favorites(params)
            elif params['action'] == 'tv_listing':
                self.__list_channels(params)
            elif params['action'] == 'vod_listing':
                self.__list_vod(params)
            elif params['action'] == 'series_listing':
                self.__list_series(params)
            elif params['action'] == 'season_listing':
                self.__list_season(params)
            elif params['action'] == 'sub_folder':
                self.__list_episodes(params)
            elif params['action'] == 'play':
                self.__play_video(params)
            elif params['action'] == 'tv_play':
                self.__play_tv(params)
            elif params['action'] == 'vod_search':
                self.__search_vod(params)
            elif params['action'] == 'series_search':
                self.__search_series(params)
            elif params['action'] == 'tv_search':
                self.__search_tv(params)
            elif params['action'] == 'remove_fav':
                self.__toggle_favorites(params['video_id'], False, params['_type'])
            elif params['action'] == 'add_fav':
                self.__toggle_favorites(params['video_id'], True, params['_type'])
            elif params['action'] == 'refresh_all':
                self.__refresh_all_data(silent=params.get('silent') == '1')
            elif params['action'] == 'update_new_data':
                self.__update_new_data(silent=params.get('silent') == '1')
            elif params['action'] == 'manage_folders':
                self.__manage_folder_selection(params)
            elif params['action'] == 'stalker_cache_info':
                self.__stalker_cache_info()
            elif params['action'] == 'stalker_clear_cache':
                self.__stalker_clear_cache()
            elif params['action'] == 'tmdb_cache_info':
                self.__show_tmdb_cache_info()
            elif params['action'] == 'tmdb_refresh_now':
                self.__tmdb_refresh_now()
            elif params['action'] == 'tmdb_clear_cache':
                self.__tmdb_clear_cache()
            elif params['action'] == 'vod_filter':
                self.__vod_filter(params)
            elif params['action'] == 'series_filter':
                self.__series_filter(params)
            else:
                raise ValueError('Invalid param string: {}!'.format(param_string))
        else:
            self.__list_main_menu()


def run(argv):
    """Run"""
    global _tmdb_client_singleton, _rate_limit_notified
    # Reset per-run state so that setting changes take effect immediately
    # without requiring a Kodi restart.
    _tmdb_client_singleton = None
    _rate_limit_notified = False
    G.init_globals()
    _build_lang_tag_pattern()
    stalker_addon = StalkerAddon()
    stalker_addon.router(argv[2][1:])
